
* Les fichiers avec le suffixe _Bis sont à utiliser avec

	https://www.jdoodle.com/execute-ada-online/

  qui n'autorise qu'un seul fichier.  Ils incluent dans le programme principal
  le module Dates ou le module Stock_Materiels suivant le cas.  On perd
  l'intérêt d'un module qui peut être utilisé par plusieurs programme mais il
  permettra de faire le TP...

* Pour une utilisation avec gnat, il faut utiliser les fichiers sans suffixe.

