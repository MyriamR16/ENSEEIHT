(* Module de la passe de gestion des placement dans la mémoire, conforme à l'interface Passe *)
open Tds
open Exceptions
open Ast

type t1 = Ast.AstSyntax.programme
type t2 = Ast.AstTds.programme

(* analyse_tds_affectable : tds -> AstSyntax.affectable -> bool -> AstTds.affectable *)
(* Paramètre tds : la table des symboles courante *)
(* Paramètre a : l'affectable à analyser *)
(* Paramètre en_ecriture : Un booléen indiquant si l'affectable est en mode écriture (true) ou en mode lecture (false).*)
(* Vérifie la bonne utilisation des identifiants et transforme l'affectable
  en un affectable de type AstTds.affectable *)
(* Erreur si mauvaise utilisation des identifiants *)
let rec analyse_tds_affectable tds a en_ecriture = 
  match a with 
    | AstSyntax.Ident s -> 
      begin
        match chercherGlobalement tds s with 
        | None -> raise (IdentifiantNonDeclare s)
        | Some info ->
          begin
            match info_ast_to_info info with
            | InfoVar _ -> AstTds.Ident info
            | InfoConst _ -> 
              (* Si l'affectable est une constante et qu'on essaie de l'écrire: on lève une erreur *)
              if en_ecriture then raise (MauvaiseUtilisationIdentifiant s)
              (* Sinon, on retourne l'identifiant *)
              else AstTds.Ident info
            | _ ->  raise (MauvaiseUtilisationIdentifiant s)
          end
      end
    | AstSyntax.Deref a -> 
      (* Analyse récursive de l'affectable deref *)
      let na = analyse_tds_affectable tds a en_ecriture in
      AstTds.Deref na 

(* analyse_tds_expression : tds -> AstSyntax.expression -> AstTds.expression *)
(* Paramètre tds : la table des symboles courante *)
(* Paramètre e :l'expression à analyser *)
(* Vérifie la bonne utilisation des identifiants et tranforme l'expression
en une expression de type AstTds.expression *)
(* Erreur si mauvaise utilisation des identifiants *)
let rec analyse_tds_expression tds e = 
  match e with
  | AstSyntax.Affectable a -> 
    begin 
      let na = analyse_tds_affectable tds a false in 
      match na with 
      | AstTds.Ident info -> 
        begin 
          match info_ast_to_info info with 
          | InfoConst (_,v)  -> AstTds.Entier v 
          | _ -> AstTds.Affectable na
        end
      | Deref _ -> AstTds.Affectable na
    end 
  | AstSyntax.AppelFonction (s, le) -> 
    begin 
      match chercherGlobalement tds s with 
      | None -> raise (IdentifiantNonDeclare s)
      | Some info ->
        begin
          match info_ast_to_info info with
          | InfoFun _ -> 
            (* Analyse des expressions des arguments de la fonction *)
            let letds = List.map (analyse_tds_expression tds) le in 
            AstTds.AppelFonction (info,letds)
          | _ ->  raise (MauvaiseUtilisationIdentifiant s)
        end
    end 
  | AstSyntax.Booleen b -> AstTds.Booleen b 
  | AstSyntax.Entier n -> AstTds.Entier n 
  | AstSyntax.Unaire (opu,exp) -> 
    (* Analyse de l'expression unitaire *)
    let ne = analyse_tds_expression tds exp in
    AstTds.Unaire (opu,ne)
  | AstSyntax.Binaire (opb,exp1,exp2) -> 
    (* Analyse des deux expressions binaires *)
    let ne1 = analyse_tds_expression tds exp1 in
    let ne2 = analyse_tds_expression tds exp2 in
    AstTds.Binaire (opb,ne1,ne2)
  (* Pointeur Null *)
  | AstSyntax.Null -> AstTds.Null
  (* Pointeur sur nouvelle variable *)
  | AstSyntax.New  t -> AstTds.New t
  (* Obtention de l'adresse d'une variable *)
  | AstSyntax.Adresse n ->  
    begin 
      match chercherGlobalement tds n with 
      | None -> raise (IdentifiantNonDeclare n)
      | Some ia -> 
        begin 
        match info_ast_to_info ia with 
          | InfoVar _ -> AstTds.Adresse ia
          | _ -> raise (MauvaiseUtilisationIdentifiant n)
        end
    end

(* analyse_tds_instruction : tds -> info_ast option -> AstSyntax.instruction -> AstTds.instruction *)
(* Paramètre tds : la table des symboles courante *)
(* Paramètre oia : None si l'instruction i est dans le bloc principal,
                   Some ia où ia est l'information associée à la fonction dans laquelle est l'instruction i sinon *)
(* Paramètre i : l'instruction à analyser *)
(* Vérifie la bonne utilisation des identifiants et tranforme l'instruction
en une instruction de type AstTds.instruction *)
(* Erreur si mauvaise utilisation des identifiants *)
let rec analyse_tds_instruction tds oia i =
  match i with
  | AstSyntax.Declaration (t, n, e) ->
      begin
        match chercherLocalement tds n with
        | None ->
            (* L'identifiant n'est pas trouvé dans la tds locale,
            il n'a donc pas été déclaré dans le bloc courant *)
            (* Vérification de la bonne utilisation des identifiants dans l'expression *)
            (* et obtention de l'expression transformée *)
            let ne = analyse_tds_expression tds e in
            (* Création de l'information associée à l'identfiant *)
            let info = InfoVar (n,Undefined, 0, "") in
            (* Création du pointeur sur l'information *)
            let ia = info_to_info_ast info in
            (* Ajout de l'information (pointeur) dans la tds *)
            ajouter tds n ia;
            (* Renvoie de la nouvelle déclaration où le nom a été remplacé par l'information
            et l'expression remplacée par l'expression issue de l'analyse *)
            AstTds.Declaration (t, ia, ne)
        | Some _ ->
            (* L'identifiant est trouvé dans la tds locale,
            il a donc déjà été déclaré dans le bloc courant *)
            raise (DoubleDeclaration n)
      end
  | AstSyntax.DeclarationStatique (t, n, e) ->
      begin
        (* On récupère l'information associée à la fonction à laquelle la variable locale statique est associée *)
        match oia with
          (* Il n'y a pas d'information -> l'instruction est dans le bloc principal : erreur *)
        | None -> raise VariableStatiqueLocaleDansMain
          (* Il y a une information -> l'instruction est dans une fonction *)
        | Some _ ->
          begin
            match chercherLocalement tds n with
            | None ->
                (* L'identifiant n'est pas trouvé dans la tds locale,
                il n'a donc pas été déclaré dans la fonction courante *)
                (* Vérification de la bonne utilisation des identifiants dans l'expression *)
                (* et obtention de l'expression transformée *)
                let ne = analyse_tds_expression tds e in
                (* Création de l'information associée à l'identfiant *)
                let info = InfoVar (n,Undefined, 0, "") in
                (* Création du pointeur sur l'information *)
                let info_ia = info_to_info_ast info in
                (* Ajout de l'information dans la tds *)
                ajouter tds n info_ia;
                (* Renvoie de la nouvelle déclaration où le nom a été remplacé par l'information
                et l'expression remplacée par l'expression issue de l'analyse *)
                AstTds.DeclarationStatique (t, info_ia, ne)
            | Some ia ->
                (* L'identifiant est trouvé dans la tds locale,
                il a donc déjà été déclaré dans la fonction courante et utilisé. *)
                (* on retourne donc la dernière valeur de cette variable statique. *)
                let ne = analyse_tds_expression tds e in
                AstTds.DeclarationStatique (t, ia, ne)
            end
      end
  | AstSyntax.Affectation (a,e) ->
      (* Analyse de l'affectable en mode écriture (en_ecriture = true)*)
      let na = analyse_tds_affectable tds a true in 
      (* Analyse de l'expression *)
      let ne = analyse_tds_expression tds e in 
      (* Renvoie de la nouvelle affectation où l'affectable et l'expression sont remplacés 
         par ceux issus de l'analyse *)
      AstTds.Affectation(na,ne)
  | AstSyntax.Constante (n,v) ->
      begin
        match chercherLocalement tds n with
        | None ->
          (* L'identifiant n'est pas trouvé dans la tds locale,
             il n'a donc pas été déclaré dans le bloc courant *)
          (* Ajout dans la tds de la constante *)
          ajouter tds n (info_to_info_ast (InfoConst (n,v)));
          (* Suppression du noeud de déclaration des constantes devenu inutile *)
          AstTds.Empty
        | Some _ ->
          (* L'identifiant est trouvé dans la tds locale,
          il a donc déjà été déclaré dans le bloc courant *)
          raise (DoubleDeclaration n)
      end
  | AstSyntax.Affichage e ->
      (* Vérification de la bonne utilisation des identifiants dans l'expression *)
      (* et obtention de l'expression transformée *)
      let ne = analyse_tds_expression tds e in
      (* Renvoie du nouvel affichage où l'expression remplacée par l'expression issue de l'analyse *)
      AstTds.Affichage (ne)
  | AstSyntax.Conditionnelle (c,t,e) ->
      (* Analyse de la condition *)
      let nc = analyse_tds_expression tds c in
      (* Analyse du bloc then *)
      let tast = analyse_tds_bloc tds oia t in
      (* Analyse du bloc else *)
      let east = analyse_tds_bloc tds oia e in
      (* Renvoie la nouvelle structure de la conditionnelle *)
      AstTds.Conditionnelle (nc, tast, east)
  | AstSyntax.TantQue (c,b) ->
      (* Analyse de la condition *)
      let nc = analyse_tds_expression tds c in
      (* Analyse du bloc *)
      let bast = analyse_tds_bloc tds oia b in
      (* Renvoie la nouvelle structure de la boucle *)
      AstTds.TantQue (nc, bast)
  | AstSyntax.Retour (e) ->
      begin
      (* On récupère l'information associée à la fonction à laquelle le return est associée *)
      match oia with
        (* Il n'y a pas d'information -> l'instruction est dans le bloc principal : erreur *)
      | None -> raise RetourDansMain
        (* Il y a une information -> l'instruction est dans une fonction *)
      | Some ia ->
        (* Analyse de l'expression *)
        let ne = analyse_tds_expression tds e in
        AstTds.Retour (ne,ia)
      end


(* analyse_tds_bloc : tds -> info_ast option -> AstSyntax.bloc -> AstTds.bloc *)
(* Paramètre tds : la table des symboles courante *)
(* Paramètre oia : None si le bloc li est dans le programme principal,
                   Some ia où ia est l'information associée à la fonction dans laquelle est le bloc li sinon *)
(* Paramètre li : liste d'instructions à analyser *)
(* Vérifie la bonne utilisation des identifiants et tranforme le bloc en un bloc de type AstTds.bloc *)
(* Erreur si mauvaise utilisation des identifiants *)
and analyse_tds_bloc tds oia li =
  (* Entrée dans un nouveau bloc, donc création d'une nouvelle tds locale
  pointant sur la table du bloc parent *)
  let tdsbloc = creerTDSFille tds in
  (* Analyse des instructions du bloc avec la tds du nouveau bloc.
     Cette tds est modifiée par effet de bord *)
   let nli = List.map (analyse_tds_instruction tdsbloc oia) li in
   (* afficher_locale tdsbloc ; *) (* décommenter pour afficher la table locale *)
   nli


(* analyse_tds_param : tds -> (typ * string) -> (typ * info_ast) *)
(* Paramètre tds : la table des symboles courante *)
(* Paramètre (t, n) : le type et le nom du paramètre à analyser *)
(* Vérifie la bonne utilisation des identifiants et transforme le paramètre
  en un paramètre de type (typ * info_ast) *)
(* Erreur si mauvaise utilisation des identifiants *)
let analyse_tds_param tds (t,n) = 
  match chercherLocalement tds n with 
  | Some _ -> raise (DoubleDeclaration n)
  | None -> 
      (* L'identifiant n'est pas trouvé dans la tds locale,
         il n'a donc pas été déclaré dans le bloc courant *)
      (* Création de l'information associée à l'identifiant *)
      let info = InfoVar(n,Undefined, 0, "") in 
      (* Création du pointeur sur l'information *)
      let ia = info_to_info_ast info in 
      (* Ajout de l'information (pointeur) dans la tds *)
      ajouter tds n ia; 
      (* Renvoie du type et de l'information associée *)
      (t, ia)

(* analyse_tds_params : tds -> (typ * string) list -> (typ * info_ast) list *)
(* Paramètre tds : la table des symboles courante *)
(* Paramètre lp : la liste des paramètres à analyser *)
(* Vérifie la bonne utilisation des identifiants et transforme chaque paramètre
  en un paramètre de type (typ * info_ast) *)
(* Erreur si mauvaise utilisation des identifiants *)
let analyse_tds_params tds lp = 
  List.map (analyse_tds_param tds) lp

(* analyse_tds_fonction : tds -> AstSyntax.fonction -> AstTds.fonction *)
(* Paramètre tds : la table des symboles courante *)
(* Paramètre : la fonction à analyser *)
(* Vérifie la bonne utilisation des identifiants et tranforme la fonction
en une fonction de type AstTds.fonction *)
(* Erreur si mauvaise utilisation des identifiants *)
let analyse_tds_fonction maintds (AstSyntax.Fonction(t,n,lp,li))  =
  match chercherGlobalement maintds n with
  | Some _ -> raise (DoubleDeclaration n) (* Si la fonction est déjà déclarée globalement: erreur *)
  | None -> 
    (* Création de l'information associée à la fonction *)
    let info = InfoFun(n, t, List.map fst lp) in 
    (* Création du pointeur sur l'information *)
    let ia = info_to_info_ast info in 
    (* Ajout de l'information (pointeur) dans la table des symboles globale *)
    ajouter maintds n ia;  
    (* Création d'une nouvelle table des symboles pour les paramètres de la fonction *)
    let tdsParam = creerTDSFille maintds in
    (* Analyse des paramètres de la fonction *)
    let nlp = analyse_tds_params tdsParam lp in
    (* Analyse du bloc d'instructions de la fonction *)
    let nli = analyse_tds_bloc tdsParam (Some ia) li in 
    (* Renvoie de la nouvelle fonction où les noms et les expressions sont remplacés par ceux issus de l'analyse *)
    AstTds.Fonction(t,ia,nlp,nli)

(* analyse_tds_variable_globale : tds -> AstSyntax.variableGlobale -> AstTds.variableGlobale *)
(* Paramètre tds : la table des symboles courante *)
(* Paramètre : la variable globale (déclaration globale) à analyser *)
(* Vérifie la bonne utilisation des identifiants et transforme la variable globale de type AstSyntax.variableGlobale
en une variable globale de type AstTds.variableGlobale *)
(* Erreur si mauvaise utilisation des identifiants *)
let analyse_tds_variable_globale maintds (AstSyntax.DeclarationGlobale(t,n,e)) =
  begin
    match chercherGlobalement maintds n with
    | None ->
        (* L'identifiant n'est pas trouvé dans la maintds,
        il n'a donc pas été déclaré avant *)
        (* Vérification de la bonne utilisation des identifiants dans l'expression *)
        (* et obtention de l'expression transformée *)
        let ne = analyse_tds_expression maintds e in
        (* Création de l'information associée à l'identfiant *)
        let info = InfoVar (n,Undefined, 0, "") in
        (* Création du pointeur sur l'information *)
        let ia = info_to_info_ast info in
        (* Ajout de l'information (pointeur) dans la tds *)
        ajouter maintds n ia;
        (* Renvoie de la nouvelle déclaration où le nom a été remplacé par l'information
        et l'expression remplacée par l'expression issue de l'analyse *)
        AstTds.DeclarationGlobale (t, ia, ne)
    | Some _ ->
        (* L'identifiant est trouvé dans la maintds,
        il a donc déjà été déclaré en tant que variable globale *)
        raise (DoubleDeclaration n)
  end

(* analyser : AstSyntax.programme -> AstTds.programme *)
(* Paramètre : le programme à analyser *)
(* Vérifie la bonne utilisation des identifiants et tranforme le programme
en un programme de type AstTds.programme *)
(* Erreur si mauvaise utilisation des identifiants *)
let analyser (AstSyntax.Programme (varGlobales,fonctions,prog)) =
  (* Création de la table des symboles mère *)
  let tds = creerTDSMere () in
  (* Analyse des variables globales *)
  let nvg = List.map (analyse_tds_variable_globale tds) varGlobales in
  (* Analyse des fonctions *)
  let nf = List.map (analyse_tds_fonction tds) fonctions in
  (* Analyse du bloc principal *)
  let nb = analyse_tds_bloc tds None prog in
  (* Renvoie du programme analysé *)
  AstTds.Programme (nvg,nf,nb)
