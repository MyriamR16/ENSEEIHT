open Rat
open Compilateur

(* Changer le chemin d'accès du jar. *)
let runtamcmde = "java -jar ../../../../../tests/runtam.jar"
(* let runtamcmde = "java -jar /mnt/n7fs/.../tools/runtam/runtam.jar" *)

(* Execute the TAM code obtained from the rat file and return the ouptut of this code *)
let runtamcode cmde ratfile =
  let tamcode = compiler ratfile in
  let (tamfile, chan) = Filename.open_temp_file "test" ".tam" in
  output_string chan tamcode;
  close_out chan;
  let ic = Unix.open_process_in (cmde ^ " " ^ tamfile) in
  let printed = input_line ic in
  close_in ic;
  Sys.remove tamfile;    (* à commenter si on veut étudier le code TAM. *)
  String.trim printed

(* Compile and run ratfile, then print its output *)
let runtam ratfile =
  print_string (runtamcode runtamcmde ratfile)

(****************************************)
(** Chemin d'accès aux fichiers de test *)
(****************************************)

let pathFichiersRat = "../../../../../tests/tam/avec_fonction/fichiersRat/"

(**********)
(*  TESTS *)
(**********)


(* requires ppx_expect in jbuild, and `opam install ppx_expect` *)
let%expect_test "testfun1" =
  runtam (pathFichiersRat^"testfun1.rat");
  [%expect{| 1 |}]

let%expect_test "testfun2" =
  runtam (pathFichiersRat^"testfun2.rat");
  [%expect{| 7 |}]

let%expect_test "testfun3" =
  runtam (pathFichiersRat^"testfun3.rat");
  [%expect{| 10 |}]

let%expect_test "testfun4" =
  runtam (pathFichiersRat^"testfun4.rat");
  [%expect{| 10 |}]

let%expect_test "testfun5" =
  runtam (pathFichiersRat^"testfun5.rat");
  [%expect{| |}]

let%expect_test "testfun6" =
  runtam (pathFichiersRat^"testfun6.rat");
  [%expect{|truetrue|}]

let%expect_test "testfuns" =
  runtam (pathFichiersRat^"testfuns.rat");
  [%expect{| 28 |}]

let%expect_test "factrec" =
  runtam (pathFichiersRat^"factrec.rat");
  [%expect{| 120 |}]


(* Tests pour les pointeurs: *)

let%expect_test "testPointeurs1" =
  runtam (pathFichiersRat^"testPointeurs1.rat");
  [%expect{| false |}]

let%expect_test "testPointeurs2" =
  runtam (pathFichiersRat^"testPointeurs2.rat");
  [%expect{| [1/2] |}]

let%expect_test "testPointeurs3" =
  runtam (pathFichiersRat^"testPointeurs3.rat");
  [%expect{| 15 |}]

(* Tests pour les variables globales: *)

let%expect_test "testVariableGlobale1" =
  runtam (pathFichiersRat^"testVariableGlobale1.rat");
  [%expect{| true |}]

let%expect_test "testVariableGlobale2" =
  runtam (pathFichiersRat^"testVariableGlobale2.rat");
  [%expect{| [3/4] |}]

let%expect_test "testVariableGlobale3" =
  runtam (pathFichiersRat^"testVariableGlobale3.rat");
  [%expect{| 10 |}]

(* Tests pour les variables statiques locales: *)

let%expect_test "testVariableStatiqueLocale1" =
  runtam (pathFichiersRat^"testVariableStatiqueLocale1.rat");
  [%expect{| 1 |}]

let%expect_test "testVariableStatiqueLocale2" =
  runtam (pathFichiersRat^"testVariableStatiqueLocale2.rat");
  [%expect{| true |}]

let%expect_test "testVariableStatiqueLocale3" =
  runtam (pathFichiersRat^"testVariableStatiqueLocale3.rat");
  [%expect{| 2 |}]
