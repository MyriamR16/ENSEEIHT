(* Module de la passe de génération du code en tam, conforme à l'interface Passe *)

open Ast
open Tds
open Type
open Tam
open Code

type t1 = Ast.AstPlacement.programme
type t2 = string

(* analyse_code_affectable : AstType.affectable -> bool -> int -> string *)
(* Paramètres :
  - a : l'affectable à analyser
  - en_ecriture : booléen indiquant si l'affectable est en écriture
  - nbDeref : nombre de déréférencements effectués
   Retour : string - le code TAM correspondant à l'affectable analysé
*)
let rec analyse_code_affectable a en_ecriture nbDeref = 
  (* recompose_deref : typ -> int -> string -> int * string *)
  (* Obtenir le type et reconstruire la suite des loadi successifs à partir du nombre de déréférencements *)
  (* Paramètres : 
          - t : le type de l'identifiant
          - i : le nombre de déréférencements effectués
          - loadis : l'accumulateur des loadi successifs pour accéder successivements aux valeurs des variables pointées 
     Retour : int * string - le couple avec la taille du type après i déréférencements et l'accumulateur des loadi 
  *)
  let rec recompose_deref t i loadis =
    if i = 0 then getTaille t, loadis
    else
      begin
        match t with
        | Pointeur pt -> recompose_deref pt (i - 1) (loadis ^ loadi 1)
        | _ -> failwith "impossible de déréférencer un type de base"
      end
  in
  match a with 
  | AstType.Ident info ->
    begin
      match info_ast_to_info info with 
      | InfoVar(_,t,depl,reg) -> 
        let tailleAffectable, loadis = recompose_deref t nbDeref "" in
        loada depl reg ^ loadis ^ 
        if en_ecriture then 
          storei tailleAffectable
        else
          loadi tailleAffectable
      | _ -> ""
    end
  | AstType.Deref a -> analyse_code_affectable a en_ecriture (nbDeref + 1)

(* analyse_code_expression : AstType.expression -> string *)
(* Paramètre :
  - e : l'expression à analyser
    Retour : string - le code TAM correspondant à l'expression analysée
*)
let rec analyse_code_expression (e: AstType.expression) = 
  match e with
  | AstType.Affectable a -> analyse_code_affectable a false 0
  | AstType.AppelFonction (info, le) -> 
    begin
      match info_ast_to_info info with 
      | InfoFun (id,_,_) -> 
        List.fold_left (fun acc exp -> acc ^ (analyse_code_expression exp)) "" le 
        ^ (call "SB" id) 
      | _ -> ""
    end
  | AstType.Booleen b -> if b then loadl_int 1 
                              else loadl_int 0 

  | AstType.Entier n ->  loadl_int n

  | AstType.Unaire (opu,exp) -> 
    analyse_code_expression exp ^
    begin 
      match opu with 
      | Numerateur -> pop 0 1
      | Denominateur -> pop 1 1
    end
  | AstType.Binaire (opb,exp1,exp2) -> 
    analyse_code_expression exp1  ^ analyse_code_expression exp2 ^  
    begin 
      match opb with 
        | Fraction -> call "SB" "norm"
        | PlusInt -> subr "IAdd"
        | PlusRat -> call "SB" "RAdd"
        | MultInt -> subr "IMul"
        | MultRat -> call "SB" "RMul"
        | EquInt -> subr "IEq"
        | EquBool -> subr "IEq"
        | Inf -> subr "ILss"
    end
  | AstType.Null -> ""
  | AstType.New t -> loadl_int (getTaille t) ^
                      subr "MAlloc"
  | AstType.Adresse ia -> 
    begin 
      match info_ast_to_info ia with 
      | InfoVar(_,_,dep,reg) -> loada dep reg
      | _ -> failwith "Info quoi !"
    end 

(* analyse_code_instruction : AstPlacement.instruction -> string *)
(* Paramètre :
  - i : l'instruction à analyser
    Retour : string - le code TAM correspondant à l'instruction analysée
*)
let rec analyse_code_instruction i =
  match i with
  | AstPlacement.Declaration (info, e) ->
    begin
      match info_ast_to_info info with 
      | InfoVar(_,t,dep,reg) -> push (getTaille t) ^ 
                            analyse_code_expression e ^ 
                            store (getTaille t) dep reg
      | _ -> ""
    end
  | AstPlacement.DeclarationStatique (info, e) ->
    begin
      match info_ast_to_info info with 
      | InfoVar(_,t,dep,reg) -> push (getTaille t) ^ 
                            analyse_code_expression e ^ 
                            store (getTaille t) dep reg
      | _ -> ""
    end
  | AstPlacement.Affectation (a,e) -> analyse_code_expression e ^ analyse_code_affectable a true 0
  | AstPlacement.AffichageInt e -> analyse_code_expression e ^
                                   subr "IOut"

  | AstPlacement.AffichageBool e -> analyse_code_expression e ^
                                    subr "BOut"

  | AstPlacement.AffichageRat e -> analyse_code_expression e ^
                                    call "SB" "ROut"

  | AstPlacement.Conditionnelle (c,t,e) ->
    let elseConditionnelle = label (getEtiquette ()) in 
    let finSiConditionnelle = label (getEtiquette ()) in 
      analyse_code_expression c ^
      jumpif 0 elseConditionnelle ^
      analyse_code_bloc t ^ 
      jump finSiConditionnelle ^ 
      elseConditionnelle ^ 
      analyse_code_bloc e ^
      finSiConditionnelle

  | AstPlacement.TantQue (c,b) ->
      let debutTQ = label (getEtiquette ()) in 
      let finTQ = label (getEtiquette ()) in 
      debutTQ ^
      analyse_code_expression c ^
      jumpif 0 finTQ ^ 
      analyse_code_bloc b ^
      jump debutTQ ^ 
      finTQ

  | AstPlacement.Retour (e,tailleRet, tailleParam) ->
      analyse_code_expression e ^ 
      return tailleRet tailleParam

  | AstPlacement.Empty -> ""
 
(* analyse_code_bloc : AstPlacement.bloc -> string *)
(* Paramètre :
  - b : le bloc à analyser
    Retour : string - le code TAM correspondant au bloc analysé
*)
and analyse_code_bloc (li, taille) =
  List.fold_left (fun acc i -> acc ^ (analyse_code_instruction i)) "" li ^
  pop 0 taille

(* analyse_code_fonction : AstPlacement.fonction -> string *)
(* Paramètre :
  - f : la fonction à analyser
    Retour : string - le code TAM correspondant à la fonction analysée
*)
let analyse_code_fonction (AstPlacement.Fonction(info,_,(li,taille)))  =
  let nli = analyse_code_bloc (li, taille) in
  match info_ast_to_info info with
  | InfoFun (nom,_,_) -> 
    let labelFonction = label nom in
    labelFonction ^ nli ^ halt
 | _ -> "" 

(* analyse_code_variable_globale : AstPlacement.variableGlobale -> string *)
(* Paramètre :
  - d : la variable globale à analyser
    Retour : string - le code TAM correspondant à la variable globale analysée
*)
let analyse_code_variable_globale (AstPlacement.DeclarationGlobale(info, e)) =
  match info_ast_to_info info with 
  | InfoVar(_,t,dep,reg) -> push (getTaille t) ^ 
                        analyse_code_expression e ^ 
                        store (getTaille t) dep reg
  | _ -> ""
  
(* analyse_code_variables_globales : AstPlacement.variableGlobale list -> string *)
(* Paramètre :
  - varGlobales : la liste des variables globales à analyser
    Retour : string - le code TAM correspondant aux variables globales analysées
*)
  let analyse_code_variables_globales varGlobales =
    List.fold_left (fun acc vg -> acc ^ analyse_code_variable_globale vg) "" varGlobales

(* getTailleVariableGlobale : AstPlacement.variableGlobale -> int *)
(* Paramètre :
  - d : la variable globale dont on veut obtenir la taille
    Retour : int - la taille de la variable globale
*)
let rec getTailleVariableGlobale (AstPlacement.DeclarationGlobale(info, _)) =
  match info_ast_to_info info with 
  | InfoVar(_,t,_,_) -> getTaille t
  | _ -> 0

(* getTailleVariablesGlobales : AstPlacement.variableGlobale list -> int *)
(* Paramètre :
  - varGlobales : la liste des variables globales dont on veut obtenir la taille totale
    Retour : int - la taille totale des variables globales
*)
and getTailleVariablesGlobales varGlobales =
  List.fold_left (fun acc vg -> acc + getTailleVariableGlobale vg) 0 varGlobales

(* analyser : AstPlacement.programme -> string *)
(* Paramètre :
  - programme : le programme à analyser
    Retour : string - le code TAM correspondant au programme analysé
*)
let analyser (AstPlacement.Programme (varGlobales, fonctions, (prog, taille))) =
  getEntete () ^
  (* On place les fonctions dans le fichier TAM en premier *)
  List.fold_left (fun acc f -> acc ^ analyse_code_fonction f) "" fonctions ^ 
  Tam.label "main" ^
  (* Ensuite, on place les variables globales dans le main *)
  List.fold_left (fun acc vg -> acc ^ analyse_code_variable_globale vg) "" varGlobales ^
  (* Enfin, on ajoute le code TAM associé aux instructions du bloc main de notre code RAT *)
  analyse_code_bloc (prog, taille) ^
  halt