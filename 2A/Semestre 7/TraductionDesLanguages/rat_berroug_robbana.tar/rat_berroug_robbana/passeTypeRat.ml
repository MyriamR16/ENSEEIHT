open Tds
open Type
open Exceptions
open Ast

type t1 = Ast.AstTds.programme
type t2 = Ast.AstType.programme

(* analyse_type_affectable : AstTds.affectable -> AstType.affectable * Type.typ *)
(* Paramètre a : l'affectable à analyser *)
(* Analyse le type de l'affectable et retourne un couple contenant l'affectable de type AstType.affectable et son type *)
(* Erreur si mauvaise utilisation des types *)
let rec analyse_type_affectable a = 
  match a with 
    | AstTds.Ident info ->  
      begin
        match info_ast_to_info info with
        | InfoVar (_,t,_,_)-> (AstType.Ident info, t) 
        | InfoConst _ -> (AstType.Ident info, Int) 
        | _ ->  failwith "Ce cas ne doit pas être traité !" 
      end
    | AstTds.Deref a -> let taff, ta = analyse_type_affectable a in 
      begin
        match ta with 
        (* Le déréférencement ne peut se faire que sur un pointeur. *)
        | Pointeur t -> (AstType.Deref taff, t) (* Si c'est un pointeur, on retourne le déréférencement et le type pointé *)
        | _ -> raise DeferencementNonPossible (* Sinon, on lève une exception *)
      end

(* analyse_type_expression : AstTds.expression -> AstType.expression * Type.typ *)
(* Paramètre e : l'expression à analyser *)
(* Analyse le type de l'expression et retourne un couple contenant l'expression de type AstType.expression et son type *)
(* Erreur si mauvaise utilisation des types *)
let rec analyse_type_expression e = 
  match e with
  | AstTds.Affectable a -> (*analyse_type_affectable a*)
                          let na,ta = analyse_type_affectable a in 
                          AstType.Affectable na,ta

  | AstTds.AppelFonction (info, le) -> 
    begin 
      match info_ast_to_info info with
      | InfoFun (_,tr,ltp)-> let l = List.map analyse_type_expression le in 
                             let nle = List.map fst l in 
                             let nlp = List.map snd l in 
                             if est_compatible_list ltp nlp then 
                                (AstType.AppelFonction(info,nle),tr)
                            else raise (TypesParametresInattendus (ltp,nlp))
      | _ ->  failwith "Ce cas ne doit pas être traité !"
        
    end 
   
  | AstTds.Booleen b -> (AstType.Booleen b , Bool)
  | AstTds.Entier n -> (AstType.Entier n , Int)

  | AstTds.Unaire (opu,exp) -> 
    let (ne,te) = analyse_type_expression exp in
    begin 
      match opu,te with 
      | Numerateur, Rat -> (AstType.Unaire(Numerateur, ne),Int)
      | Denominateur, Rat-> (AstType.Unaire(Denominateur, ne),Int)
      | _,t -> raise (TypeInattendu (t, Rat))
    end
    
  | AstTds.Binaire (opb,exp1,exp2) -> 
    let (ne1,te1) = analyse_type_expression exp1 in
    let (ne2,te2) = analyse_type_expression exp2 in
    (* Surcharge des opérateurs binaires *)
    begin
      match te1,opb,te2 with 
        | Int, Fraction, Int -> (AstType.Binaire(Fraction, ne1,ne2),Rat) 
        | Int, Plus, Int -> (AstType.Binaire(PlusInt, ne1,ne2),Int)
        | Rat, Plus, Rat -> (AstType.Binaire(PlusRat, ne1,ne2),Rat)
        | Int, Mult, Int -> (AstType.Binaire(MultInt, ne1,ne2),Int)
        | Rat, Mult, Rat -> (AstType.Binaire(MultRat, ne1,ne2),Rat)
        | Int, Equ, Int -> (AstType.Binaire(EquInt, ne1,ne2),Bool)
        | Bool, Equ, Bool -> (AstType.Binaire(EquBool, ne1,ne2),Bool)
        | Int, Inf, Int -> (AstType.Binaire(Inf, ne1,ne2),Bool)
        | _ -> raise (TypeBinaireInattendu (opb,te1,te2))
    end
  (* Pointeur Null *)
  | AstTds.Null -> (AstType.Null, Pointeur Undefined)
  (* Pointeur sur nouvelle variable *)
  | AstTds.New t -> (AstType.New t, Pointeur t)
  (* Obtention de l'adresse d'une variable *)
  | AstTds.Adresse ia -> 
    begin
      match info_ast_to_info ia with 
      (* Un pointeur est forcément une variable, donc c'est le seul cas à prendre en compte.*)
      | InfoVar (_,t,_,_) -> (AstType.Adresse ia, Pointeur t)
      | _ -> failwith "Ce cas ne doit pas être traité !"
    end

(* analyse_type_instruction : AstTds.instruction -> AstType.instruction *)
(* Paramètre i : l'instruction à analyser *)
(* Analyse le type de l'instruction et retourne l'instruction de type AstType.instruction *)
(* Erreur si mauvaise utilisation des types *)
let rec analyse_type_instruction i =
  match i with
  | AstTds.Declaration (t, info, e) ->
      let (ne,te) = analyse_type_expression e in
      if (est_compatible t te) then 
        begin
          modifier_type_variable t info;
          AstType.Declaration (info,ne)
        end
      else
        raise (TypeInattendu (te,t))
  | AstTds.DeclarationStatique (t, info, e) ->
      let (ne,te) = analyse_type_expression e in
      if (est_compatible t te) then 
        begin
          modifier_type_variable t info;
          AstType.DeclarationStatique (info,ne)
        end
      else
        raise (TypeInattendu (te,t))
  | AstTds.Affectation (a,e) ->
      begin
        let (na, ta) = analyse_type_affectable a in
        let (ne, te) = analyse_type_expression e in
        if est_compatible ta te then 
          AstType.Affectation(na, ne)
        else
          raise (TypeInattendu (te, ta))
      end

  | AstTds.Affichage e ->
     let (ne,te) =analyse_type_expression e in 
     begin 
      match te with 
        | Int -> AstType.AffichageInt (ne)
        | Bool -> AstType.AffichageBool (ne)
        | Rat -> AstType.AffichageRat (ne)
        | _ -> failwith "Attention c est pas le bon type !"
     end 

  | AstTds.Conditionnelle (c,t,e) ->
      let (nc,tc) =analyse_type_expression c in
      if est_compatible tc Bool then 
        let nt = analyse_type_bloc t in 
        let ne = analyse_type_bloc e in 
        AstType.Conditionnelle (nc,nt,ne)
      else 
        raise (TypeInattendu (tc,Bool))

  | AstTds.TantQue (c,b) ->
      let (nc,tc) = analyse_type_expression c in
      if est_compatible tc Bool then 
        let nb = analyse_type_bloc b in 
      
        AstType.TantQue (nc,nb)
      else 
        raise (TypeInattendu (tc, Bool))

  | AstTds.Retour (e, ia) ->
      begin
        let (ne,te) = analyse_type_expression e in
        match info_ast_to_info ia with 
        | InfoFun(_,t,_) -> if est_compatible t te then AstType.Retour (ne,ia)
                            else raise (TypeInattendu(te,t))
        | _ -> failwith "Ce cas ne doit pas être traité !"
      end 

  | AstTds.Empty -> AstType.Empty

(* analyse_type_bloc : AstTds.instruction list -> AstType.instruction list *)
(* Paramètre li : la liste d'instructions à analyser *)
(* Analyse le type de chaque instruction dans la liste et retourne une liste d'instructions de type AstType.instruction *)
(* Erreur si mauvaise utilisation des types *)
and analyse_type_bloc li =
   let nli = List.map analyse_type_instruction li in
   nli

(* analyser_type_param : Type.typ * Tds.info_ast -> Tds.info_ast *)
(* Paramètre tp : le type du paramètre *)
(* Paramètre info : l'information associée au paramètre *)
(* Modifie le type de la variable associée au paramètre et retourne l'information mise à jour *)
let analyser_type_param (tp,info) = 
  modifier_type_variable tp info; 
  info

(* analyser_type_params : (Type.typ * Tds.info_ast) list -> Tds.info_ast list *)
(* Paramètre lp : la liste des paramètres à analyser *)
(* Analyse le type de chaque paramètre dans la liste et retourne une liste d'informations mises à jour *)
let analyser_type_params lp = 
  List.map analyser_type_param lp

(* analyse_type_fonction : AstTds.fonction -> AstType.fonction *)
(* Paramètre f : la fonction à analyser *)
(* Analyse le type de la fonction et retourne la fonction de type AstType.fonction *)
(* Erreur si mauvaise utilisation des types *)
let analyse_type_fonction (AstTds.Fonction(t,ia,ltiap,li))  =
  modifier_type_fonction t (List.map fst ltiap) ia;
  let nlp = analyser_type_params ltiap in 
  let nli = analyse_type_bloc li in
  AstType.Fonction(ia,nlp,nli)

(* analyse_type_variable_globale : AstTds.variableGlobale -> AstType.variableGlobale *)
(* Paramètre vg : la variable globale à analyser *)
(* Analyse le type de la variable globale et retourne la variable globale de type AstType.variableGlobale *)
(* Erreur si mauvaise utilisation des types *)
let analyse_type_variable_globale (AstTds.DeclarationGlobale(t, info, e)) = 
  let (ne,te) = analyse_type_expression e in
  if (est_compatible t te) then 
    begin
      modifier_type_variable t info;
      AstType.DeclarationGlobale (info,ne)
    end
  else
    raise (TypeInattendu (te,t))

(* analyser : AstTds.programme -> AstType.programme *)
(* Paramètre p : le programme à analyser *)
(* Analyse le type du programme et retourne le programme de type AstType.programme *)
(* Erreur si mauvaise utilisation des types *)
(* Module de la passe de gestion des types, conforme à l'interface Passe *)
let analyser (AstTds.Programme (varGlobales,fonctions,prog)) =
  let nvg = List.map analyse_type_variable_globale varGlobales in
  let nf = List.map analyse_type_fonction fonctions in
  let nb = analyse_type_bloc prog in
  AstType.Programme (nvg,nf,nb)