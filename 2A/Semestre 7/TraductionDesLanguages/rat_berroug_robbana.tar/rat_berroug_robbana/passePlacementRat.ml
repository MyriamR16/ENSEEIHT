(* Module de la passe de gestion des types, conforme à l'interface Passe *)

open Type
open Tds
open Ast

type t1 = Ast.AstType.programme
type t2 = Ast.AstPlacement.programme

(* analyser_placement_instruction : AstType.instruction -> int -> int -> string -> AstPlacement.instruction * int *)
(* Paramètres :
  - i : l'instruction à analyser
  - depl : le déplacement courant
  - depl_stat : le déplacement statique courant
  - reg : le registre courant
  Analyse le placement de l'instruction et retourne l'instruction de type AstPlacement.instruction et la taille de l'instruction *)
let rec analyser_placement_instruction i depl depl_stat reg =
  match i with
  | AstType.Declaration (info, e) -> modifier_adresse_variable depl reg info ;
    begin
      match info_ast_to_info info with 
      | InfoVar (_,t,_,_) -> (AstPlacement.Declaration(info,e), getTaille t) (* Retourne la taille pour ajuster le déplacement *)
      | _ -> failwith "Ce cas ne doit pas être traité !"
    end
  | AstType.DeclarationStatique (info, e) -> modifier_adresse_variable depl reg info ;
    begin
      match info_ast_to_info info with 
      | InfoVar (_,t,_,_) -> (AstPlacement.DeclarationStatique(info,e), getTaille t) (* Retourne la taille pour ajuster le déplacement statique *)
      | _ -> failwith "Ce cas ne doit pas être traité !"
    end
    
  | AstType.Affectation (a,e) -> (AstPlacement.Affectation(a,e), 0)

  | AstType.AffichageInt e -> (AstPlacement.AffichageInt e, 0)

  | AstType.AffichageBool e -> (AstPlacement.AffichageBool e, 0)
  
  | AstType.AffichageRat e -> (AstPlacement.AffichageRat e, 0)

  | AstType.Conditionnelle (c,t,e) ->
    let (nt,_) = analyser_placement_bloc t depl depl_stat reg in 
    let (ne,_) = analyser_placement_bloc e depl depl_stat reg in 
    (AstPlacement.Conditionnelle (c,nt,ne), 0)

  | AstType.TantQue (c,b) ->
    let (nb,_) = analyser_placement_bloc b depl 0 reg in 
    (AstPlacement.TantQue (c,nb), 0)

  | AstType.Retour (e, ia) ->
    begin
      match info_ast_to_info ia with 
      | InfoFun (_,tr,ltp) -> (AstPlacement.Retour (e,getTaille tr, (List.fold_left (fun acc t -> acc + getTaille t) 0 ltp)), 0)
      | _ -> failwith "Ce cas ne doit pas être traité !"
    end

  | AstType.Empty -> (AstPlacement.Empty, 0)

(* analyser_placement_bloc : AstType.bloc -> int -> int -> string -> (AstPlacement.bloc * int) * int *)
(* Paramètres :
  - li : la liste d'instructions à analyser
  - depl : le déplacement courant
  - depl_stat : le déplacement statique courant
  - reg : le registre courant
  Analyse le placement du bloc et retourne le bloc de type AstPlacement.bloc et la taille du bloc *)
and analyser_placement_bloc li depl depl_stat reg =
   match li with 
   | [] -> (([], 0), 0)
   | i::q ->
          match i with
          | AstType.DeclarationStatique(_, _) -> 
                  (* on utilise le déplacement statique pour les variables statiques *)
                  let (ni,ti) = analyser_placement_instruction i depl_stat 0 "SB" in 
                  let ((nq,tq),taille_stat_q) = analyser_placement_bloc q depl (depl_stat + ti) reg in
                  ((ni::nq, ti+tq), ti + taille_stat_q)
          | _ -> 
                  (* on utilise le déplacement depl pour les autres variables *)
                  let (ni,ti) = analyser_placement_instruction i depl depl_stat reg in 
                  let ((nq,tq), taille_stat) = analyser_placement_bloc q (depl + ti) depl_stat reg in 
                  ((ni::nq, ti+tq), taille_stat)

(* analyser_placement_param : Tds.info_ast -> int -> string -> Tds.info_ast * int *)
(* Paramètres :
  - info : l'information de l'AST à analyser
  - depl : le déplacement courant
  - reg : le registre courant
  Analyse le placement du paramètre et retourne l'information de l'AST et la taille du paramètre *)
let analyser_placement_param info depl reg = 
  modifier_adresse_variable depl reg info; 
  begin
    match info_ast_to_info info with 
    | InfoVar (_,t,_,_) -> (info, getTaille t)
    | _ -> failwith "Ce cas ne doit pas être traité !"
  end

(* analyser_placement_params : Tds.info_ast list -> int -> string -> Tds.info_ast list * int *)
(* Paramètres :
  - lp : la liste des informations de l'AST à analyser
  - depl : le déplacement courant
  - reg : le registre courant
  Analyse le placement des paramètres et retourne la liste des informations de l'AST et la taille totale des paramètres *)
let rec analyser_placement_params lp depl reg = 
  match lp with 
  | [] -> ([],0)
  | i::q -> let (ni,ti) = analyser_placement_param i depl reg in 
            let (nq,tq) = analyser_placement_params q (depl+ti) reg in 
            (ni::nq, -(ti+tq)) (* Retourne la taille totale des paramètres pour ajuster le déplacement *)

(* getTailleListeInfo : Tds.info_ast list -> int *)
(* Paramètre lp : la liste des informations de l'AST
  Retourne la taille totale des informations de l'AST.
  Cette fonction est utilisée dans analyser_placement_fonction pour obtenir la taille des paramètres, 
  et ainsi donner le bon déplacement négatif au premier paramètre et ainsi de suite. *)
let rec getTailleListeInfo lp =
  match lp with 
  | [] -> 0 
  | i::q -> match info_ast_to_info i with 
        | InfoVar(_,t,_,_) -> (getTaille t) + getTailleListeInfo q  
        | _ -> failwith "Ce cas ne doit pas être traité !" 

(* analyser_placement_fonction : AstType.fonction * int -> AstPlacement.fonction * int *)
(* Paramètres :
  - f : la fonction à analyser
  - depl_stat : le déplacement statique courant
  Analyse le placement des paramètres de la fonction ainsi que de ses instructions,
  et retourne la fonction de type AstPlacement.fonction et la taille des variables statiques *)
let analyser_placement_fonction ((AstType.Fonction(info,lp,li)), depl_stat)  = 
  let (nli, taille_variables_statistiques) = analyser_placement_bloc li 3 depl_stat "LB" in
  let tp = getTailleListeInfo lp in
  let (nlp,_) = analyser_placement_params lp (-tp) "LB" in
  (AstPlacement.Fonction (info, nlp,nli), taille_variables_statistiques)

(* analyser_placement_variable_globale : AstType.variableGlobale -> int -> string -> AstPlacement.variableGlobale * int *)
(* Paramètres :
  - v : la variable globale à analyser
  - depl : le déplacement courant
  - reg : le registre courant
  Analyse le placement de la variable globale et retourne la variable globale de type AstPlacement.variableGlobale 
  et la taille de cette variable *)
let rec analyser_placement_variable_globale (AstType.DeclarationGlobale(info, e)) depl reg =
  modifier_adresse_variable depl reg info ;
  begin
    match info_ast_to_info info with 
    | InfoVar (_,t,_,_) -> (AstPlacement.DeclarationGlobale(info,e), getTaille t)
    | _ -> failwith "Ce cas ne doit pas être traité !"
  end
(* analyser_placement_variables_globales : AstType.variableGlobale list -> int -> string -> AstPlacement.variableGlobale list * int *)
(* Paramètres :
  - variables_globales : la liste des variables globales à analyser
  - depl : le déplacement courant
  - reg : le registre courant
  Analyse le placement des variables globales et retourne la liste des variables globales de type AstPlacement.variableGlobale 
  et la taille totale de ces variables *)
and analyser_placement_variables_globales variables_globales depl reg =
    match variables_globales with
    | [] -> ([], depl)
    | v :: q ->
        let (nv, tv) = analyser_placement_variable_globale v depl reg in
        let (nq, tq) = analyser_placement_variables_globales q (depl + tv) reg in
        (nv :: nq, tq)


(* analyser : AstType.programme -> AstPlacement.programme *)
(* Paramètre p : le programme à analyser
  Analyse le placement du programme et retourne le programme de type AstPlacement.programme *)
let analyser (AstType.Programme (varGlobales, fonctions, prog)) =
  (* On prend la liste des variables globales analysées par placement et la taille des variables globales, 
  en commençant par le déplacement 0 *)
  let (nvg, taille_variables_globales) = analyser_placement_variables_globales varGlobales 0 "SB" in
  (* On procède à l'analyse des fonctions avec les variables statiques en parallèle.
     En effet, pour chaque fonction f, on l'analyse en analysant bien sûr les variables statiques locales qui y sont définies,
     et ainsi on obtient vers la fin la liste des fonctions traitées et la somme des tailles des variables statiques locales *)
  let (nlf, taille_variables_statistiques) =
    List.fold_left
      (fun (acc, depl_stat) f ->
        let (nf, taille_stat) = analyser_placement_fonction (f, depl_stat) in
        (nf :: acc, depl_stat + taille_stat)) 
      ([], taille_variables_globales) fonctions
  in
  (* Et finalement, on analyse le bloc prog en commençant par taille_variables_statistiques *)
  let (nb, _) = analyser_placement_bloc prog taille_variables_statistiques 0 "SB" in
  AstPlacement.Programme (nvg, nlf, nb)

