+ "test.opb.txt" est un petit exemple à résoudre à la main et à comparer avec le resultat de votre code.

+ Format des noms d'instances fournies: KnapSack_* nombre d'objets *_* ordre de grandeur de la capacité du sac *_-* valeur de la solution *.opb.txt

+ Types d'instances:
- Similar_Weights : Les objets ont des poids similaires.
- Strongly_Correlated : Le prix et le poids des objets est fortement corrélé.
- Weakly_Correlated : Le prix et le poids des objets est faiblement corrélé.
- Uncorrelated : Le prix et le poids des objets n'est pas corrélé.
